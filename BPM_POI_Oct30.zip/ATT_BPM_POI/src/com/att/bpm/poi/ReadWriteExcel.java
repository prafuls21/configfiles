package com.att.bpm.poi;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import teamworks.TWObject;
import teamworks.TWObjectFactory;

public class ReadWriteExcel {

	public static void main(String[] args) throws Exception {
		ReadWriteExcel exc = new ReadWriteExcel();
		// VersioningContext versioningContext = new
		// VersioningContext("ValueBean");
		// exc.writeExcel("C:\\temp\\new.xls");
		// exc.updateExcel();
		TWObject twObject = TWObjectFactory.createObject();
		twObject.setPropertyValue("name", "ps050f");
		twObject.setPropertyValue("place", "Place");
		exc.readCreateSaveXlx("C:\\temp\\Test_Template_Rollup.xlsx", "C:\\temp\\actual_template4.xlsx", 123456,twObject,true,twObject,"Rollup");

	}

	public void writeExcel(String filePath) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Sample sheet");

		Map<String, Object[]> data = new HashMap<String, Object[]>();
		data.put("1", new Object[] { "Emp No.", "Name", "Salary" });
		data.put("2", new Object[] { 1d, "John", 1500000d });
		data.put("3", new Object[] { 2d, "Sam", 800000d });
		data.put("4", new Object[] { 3d, "Dean", 700000d });

		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof Date)
					cell.setCellValue((Date) obj);
				else if (obj instanceof Boolean)
					cell.setCellValue((Boolean) obj);
				else if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Double)
					cell.setCellValue((Double) obj);
			}
		}

		try {
			// FileOutputStream out = new FileOutputStream(new
			// File("C:\\temp\\new.xls"));
			FileOutputStream out = new FileOutputStream(new File(filePath));
			workbook.write(out);
			out.close();
			System.out.println("Excel written successfully..");
			workbook.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void updateExcel() {

		try {
			FileInputStream file = new FileInputStream(new File("C:\\temp\\new.xls"));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheetAt(0);
			Cell cell = null;

			// Update the value of cell
			cell = sheet.getRow(1).getCell(2);
			cell.setCellValue(cell.getNumericCellValue() * 2);
			cell = sheet.getRow(2).getCell(2);
			cell.setCellValue(cell.getNumericCellValue() * 2);
			cell = sheet.getRow(3).getCell(2);
			cell.setCellValue(cell.getNumericCellValue() * 2);

			file.close();

			FileOutputStream outFile = new FileOutputStream(new File("C:\\temp\\new.xls"));
			workbook.write(outFile);
			outFile.close();
			workbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	public void readCreateSaveXlx(String filePath, String targetPath, int pmattId,TWObject excelUpdates,boolean isDedug,TWObject excelUpdates2,String tabName) throws IOException {
		FileInputStream fileIn = null;
		System.out.println("filePath=" + filePath + ",targetPath=" + targetPath);
		try {

			fileIn = new FileInputStream(new File(filePath));
			XSSFWorkbook wb = new XSSFWorkbook(fileIn);
			XSSFSheet sheet = wb.getSheetAt(0);
			wb.setSheetName(0, pmattId+"");
			Cell cell = null;
			if (excelUpdates != null) {
				FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
				if (excelUpdates.getPropertyNames() != null) {
					for (Iterator<String> iterator = excelUpdates.getPropertyNames().iterator(); iterator.hasNext();) {
						String prop = iterator.next();						
						String val = (String) excelUpdates.getPropertyValue(prop);
						if(isDedug)
						{
						System.out.println("Property Name:" + prop);
						System.out.println("Property Value:" + val);
						}
						
						if (prop.indexOf("_") > -1) {
							prop = prop.split("_")[0];
						}

						if (prop.indexOf("R") > -1 && prop.indexOf("C") > -1) {
							int rowN = Integer.parseInt(prop.substring(1, prop.indexOf("C")));
							int colN = Integer.parseInt(prop.substring(prop.indexOf("C") + 1, prop.length()));
							if(isDedug)
							{
							System.out.println(rowN + "=" + colN);
							}
							// sheet.getC
							cell = sheet.getRow(rowN).getCell(colN);
							if (val != null && cell != null && val != "") {
								if(isDedug)
								{
								System.out.println("Cell TYPE==" + cell.getCellTypeEnum());
								}
								switch (formulaEvaluator.evaluateInCell(cell).getCellTypeEnum()) {
								case NUMERIC:
									if (val.indexOf("$") > -1) {
										val = val.replace("$", "");
										if(isDedug)
										{
										System.out.println("Numuric=" + val);
										}
									}
									cell.setCellValue(Double.parseDouble(val));
									break;
								case BOOLEAN:
									cell.setCellValue(Boolean.parseBoolean(val));
									if(isDedug)
									{
									System.out.println("Boolean=" + val);
									}
									break;
								case STRING:
									cell.setCellValue(val);
									if(isDedug)
									{
									System.out.println("String=" + val);
									}
									break;
								default:
									if (val.indexOf("$") > -1 && val.trim().indexOf("$")==0) {
										String newVal = val.replace("$", "");
										// cell.getC
										if(isDedug)
										{
										System.out.println("Double Number=" + val);
										}
										if (isNumeric(newVal)) {
										cell.setCellValue(Double.parseDouble(newVal));
										}else {
											cell.setCellValue(val);
										}
									} else {
										if (isNumeric(val)) {
											cell.setCellValue(Double.parseDouble(val));
										} else {
											cell.setCellValue(val);
										}
									}
									if(isDedug)
									{
									System.out.println("DeFAULT=" + val);
									}
								}

							}
						}

					}
				}

			}
			updateExcelTabAtIndex(wb, 1, excelUpdates2, isDedug, tabName);
			FileOutputStream out = new FileOutputStream(new File(targetPath));
			wb.write(out);
			out.close();
			wb.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// close input stream
			if (fileIn != null) {
				fileIn.close();
			}
		}
	}

	public String readAndCreateXlxString(String filePath, int pmattId,TWObject excelUpdates,boolean isDedug,TWObject excelUpdates2,String tabName) throws IOException {
		FileInputStream fileIn = null;
		byte[] fileContent = null;
		System.out.println("filePath=" + filePath);
		try {

			fileIn = new FileInputStream(new File(filePath));
			XSSFWorkbook wb = new XSSFWorkbook(fileIn);	

			XSSFSheet sheet = wb.getSheetAt(0);
			wb.setSheetName(0, pmattId+"");
			Cell cell = null;
			if (excelUpdates != null) {
				FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
				if (excelUpdates.getPropertyNames() != null) {
					for (Iterator<String> iterator = excelUpdates.getPropertyNames().iterator(); iterator.hasNext();) {
						String prop = iterator.next();						
						String val = (String) excelUpdates.getPropertyValue(prop);
						if(isDedug)
						{
						System.out.println("Property Name:" + prop);
						System.out.println("Property Value:" + val);
						}

						if (prop.indexOf("_") > -1) {
							prop = prop.split("_")[0];
						}

						if (prop.indexOf("R") > -1 && prop.indexOf("C") > -1) {
							int rowN = Integer.parseInt(prop.substring(1, prop.indexOf("C")));
							int colN = Integer.parseInt(prop.substring(prop.indexOf("C") + 1, prop.length()));
							if(isDedug)
							{
							System.out.println(rowN + "=" + colN);
							}
							// sheet.getC
							cell = sheet.getRow(rowN).getCell(colN);

							if (val != null && cell != null && val != "") {
								if(isDedug)
								{
								System.out.println("Cell TYPE==" + cell.getCellTypeEnum());
								}
								switch (formulaEvaluator.evaluateInCell(cell).getCellTypeEnum()) {
								case NUMERIC:
									if (val.indexOf("$") > -1) {
										val = val.replace("$", "");
										if(isDedug)
										{
										System.out.println("Numuric=" + val);
										}
									}
									cell.setCellValue(Double.parseDouble(val));
									break;
								case BOOLEAN:
									cell.setCellValue(Boolean.parseBoolean(val));
									if(isDedug)
									{
									System.out.println("Boolean=" + val);
									}
									break;
								case STRING:
									cell.setCellValue(val);
									if(isDedug)
									{
									System.out.println("String=" + val);
									}
									break;
								default:
									if (val.indexOf("$") > -1 && val.trim().indexOf("$")==0) {
										String newVal = val.replace("$", "");
										// cell.getC
										if(isDedug)
										{
										System.out.println("Double Number=" + val);
										}
										if (isNumeric(newVal)) {
										cell.setCellValue(Double.parseDouble(newVal));
										}else {
											cell.setCellValue(val);
										}
									} else {
										if (isNumeric(val)) {
											cell.setCellValue(Double.parseDouble(val));
										} else {
											cell.setCellValue(val);
										}
									}
									if(isDedug)
									{
									System.out.println("DeFAULT=" + val);
									}
								}

							}
						}

					}

				}

			}
			//wb.setSheetName(1, "Rollup");
			updateExcelTabAtIndex(wb, 1, excelUpdates2, isDedug, tabName);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			wb.write(baos);
			fileContent = baos.toByteArray();
			
			//XSSFSheet sheet1 = wb.getSheetAt(1);
			//sheet1.
			
			wb.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// close input stream
			if (fileIn != null) {
				fileIn.close();
			}
		}
		// Base64.getEncoder().
		String base64EncodedString = Base64.getEncoder().encodeToString(fileContent);
		return base64EncodedString;

	}
	
	private void updateExcelTabAtIndex(XSSFWorkbook wb,int index,TWObject excelUpdates,boolean isDedug,String tabName)
	{
		
			   XSSFFont arial10Font = wb.createFont();		    
			   arial10Font.setFontName("Arial");
			   arial10Font.setFontHeightInPoints((short) 10);
		     // wb.getSheetAt(1).getC
			
		
		XSSFSheet sheet = wb.getSheetAt(index);		
		Cell cell = null;
		if (excelUpdates != null && sheet !=null) {
			wb.setSheetName(index, tabName);
			FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
			if (excelUpdates.getPropertyNames() != null) {
				for (Iterator<String> iterator = excelUpdates.getPropertyNames().iterator(); iterator.hasNext();) {
					String prop = iterator.next();						
					String val = (String) excelUpdates.getPropertyValue(prop);
					if(isDedug)
					{
					System.out.println("Property Name:" + prop);
					System.out.println("Property Value:" + val);
					}

					if (prop.indexOf("_") > -1) {
						prop = prop.split("_")[0];
					}

					if (prop.indexOf("R") > -1 && prop.indexOf("C") > -1) {
						int rowN = Integer.parseInt(prop.substring(1, prop.indexOf("C")));
						int colN = Integer.parseInt(prop.substring(prop.indexOf("C") + 1, prop.length()));
						if(isDedug)
						{
						System.out.println(rowN + "=" + colN);
						}
						// sheet.getC
						//Cell cell1 = row.getCell(j,Row.CREATE_NULL_AS_BLANK);
						XSSFRow row = sheet.getRow(rowN);
						if(row == null)
						{
							row = sheet.createRow(rowN);
							
						}
						cell = row.getCell(colN);
						if(cell == null)
						{
							cell = row.createCell(colN);
						}

						if (val != null && cell != null && val != "") {
							if(isDedug)
							{
							System.out.println("Cell TYPE==" + cell.getCellTypeEnum());
							}
							CellUtil.setFont(cell, arial10Font);
							switch (formulaEvaluator.evaluateInCell(cell).getCellTypeEnum()) {
							case NUMERIC:
								if (val.indexOf("$") > -1) {
									val = val.replace("$", "");
									if(isDedug)
									{
									System.out.println("Numuric=" + val);
									}
								}
								cell.setCellValue(Double.parseDouble(val));
								break;
							case BOOLEAN:
								cell.setCellValue(Boolean.parseBoolean(val));
								if(isDedug)
								{
								System.out.println("Boolean=" + val);
								}
								break;
							case STRING:
								cell.setCellValue(val);
								if(isDedug)
								{
								System.out.println("String=" + val);
								}
								break;
							default:
								if (val.indexOf("$") > -1) {
									val = val.replace("$", "");
									if(isDedug)
									{
									System.out.println("Double Number=" + val);
									}
									cell.setCellValue(Double.parseDouble(val));
								} else {
									if (isNumeric(val)) {
										cell.setCellValue(Double.parseDouble(val));
									} else {
										cell.setCellValue(val);
									}
								}
								if(isDedug)
								{
								System.out.println("DeFAULT=" + val);
								}
							}

						}
					}

				}

			}

		}
	
			
	}

	public static boolean isNumeric(String str) {
		return str.matches("-?\\d+(\\.\\d+)?"); // match a number with optional
												// '-' and decimal.
	}

	public static double round12UnUsed(double d) {
		BigDecimal bd = new BigDecimal(d);
		bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
		return bd.doubleValue();

	}

}
