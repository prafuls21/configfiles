package com.att.bpm.poi;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestReadUpdateExcel {

	public static void main(String[] args) throws Exception {
		TestReadUpdateExcel exc = new TestReadUpdateExcel();
		// VersioningContext versioningContext = new
		// VersioningContext("ValueBean");
		// exc.writeExcel("C:\\temp\\new.xls");
		// exc.updateExcel();
		// TWObject twObject = TWObjectFactory.createObject("ValueBean" );
		// //("BeanInfo");
		// twObject.setPropertyValue("name", "ps050f");
		// twObject.setPropertyValue("place", "Place");
		PropertyNameValue[] propArr = new PropertyNameValue[20];
		propArr[0] = new PropertyNameValue("R0C3", "33333");
		propArr[1] = new PropertyNameValue("R0C5", "08/21/2020");
		propArr[2] = new PropertyNameValue("R0C8", "13022.37");
		propArr[19] = new PropertyNameValue("R16C11", "13000.37");
		propArr[17] = new PropertyNameValue("R63C3", "$2413");
		propArr[18] = new PropertyNameValue("R12C3", "$2413.456");
		propArr[18] = new PropertyNameValue("R19C3", "241.12375");
		exc.readExcelXlx("C:\\temp\\RU_P8_Template_R2008.xlsx", "C:\\temp\\RU_P8_Template_R2010_1.xlsx",123456, propArr);

	}

	public void writeExcel(String filePath) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Sample sheet");

		Map<String, Object[]> data = new HashMap<String, Object[]>();
		data.put("1", new Object[] { "Emp No.", "Name", "Salary" });
		data.put("2", new Object[] { 1d, "John", 1500000d });
		data.put("3", new Object[] { 2d, "Sam", 800000d });
		data.put("4", new Object[] { 3d, "Dean", 700000d });

		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof Date)
					cell.setCellValue((Date) obj);
				else if (obj instanceof Boolean)
					cell.setCellValue((Boolean) obj);
				else if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Double)
					cell.setCellValue((Double) obj);
			}
		}

		try {
			// FileOutputStream out = new FileOutputStream(new
			// File("C:\\temp\\new.xls"));
			FileOutputStream out = new FileOutputStream(new File(filePath));
			workbook.write(out);
			out.close();
			System.out.println("Excel written successfully..");
			workbook.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void updateExcel() {

		try {
			FileInputStream file = new FileInputStream(new File("C:\\temp\\new.xls"));

			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheetAt(0);
			Cell cell = null;

			// Update the value of cell
			cell = sheet.getRow(1).getCell(2);
			cell.setCellValue(cell.getNumericCellValue() * 2);
			cell = sheet.getRow(2).getCell(2);
			cell.setCellValue(cell.getNumericCellValue() * 2);
			cell = sheet.getRow(3).getCell(2);
			cell.setCellValue(cell.getNumericCellValue() * 2);

			file.close();

			FileOutputStream outFile = new FileOutputStream(new File("C:\\temp\\new.xls"));
			workbook.write(outFile);
			outFile.close();
			workbook.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// actual_template.xls

	@SuppressWarnings("deprecation")
	public void readExcelXls() {
		try {

			FileInputStream file = new FileInputStream(new File("C:\\temp\\actual_template_old.xls"));

			// Get the workbook instance for XLS file
			@SuppressWarnings("resource")
			HSSFWorkbook workbook = new HSSFWorkbook(file);

			// Get first sheet from the workbook
			HSSFSheet sheet = workbook.getSheetAt(0);

			// Iterate through each rows from first sheet
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				// For each row, iterate through each columns
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {

					Cell cell = cellIterator.next();

					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_BOOLEAN:
						System.out.print(cell.getBooleanCellValue() + "\t\t");
						break;
					case Cell.CELL_TYPE_NUMERIC:
						System.out.print(cell.getNumericCellValue() + "\t\t");
						break;
					case Cell.CELL_TYPE_STRING:
						System.out.print(cell.getStringCellValue() + "\t\t");
						break;
					}
				}
				System.out.println("");
			}

			file.close();
			FileOutputStream out = new FileOutputStream(new File("C:\\test.xls"));
			workbook.write(out);
			out.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public String readExcelXlx(String filePath, String targetPath, int pmattId,PropertyNameValue[] excelUpdates)
			throws IOException {
		FileInputStream fileIn = null;
		byte[] fileContent = null;
		System.out.println("filePath=" + filePath + ",targetPath=" + targetPath);
		try {

			// FileInputStream file = new FileInputStream(new
			// File("C:\\temp\\actual_template.xlsx"));
			fileIn = new FileInputStream(new File(filePath));

			XSSFWorkbook wb = new XSSFWorkbook(fileIn);

			XSSFSheet sheet = wb.getSheetAt(0);
			
			wb.setSheetName(0, pmattId+"");
			// iterate through each row from first sheet
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				// Fore each row iterate through each column
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();

					switch (cell.getCellTypeEnum()) {
					case BOOLEAN:
						System.out.print(cell.getAddress() + " " + cell.getCellTypeEnum() + " is Boolean. Value="
								+ cell.getBooleanCellValue() + "\t\t");
						break;

					case NUMERIC:
						System.out.print(cell.getAddress() + " " + cell.getCellTypeEnum() + " is Numeric. Value="
								+ cell.getNumericCellValue() + "\t\t");
						break;

					case STRING:
						System.out.print(cell.getAddress() + " " + cell.getCellTypeEnum() + " is String. Value="
								+ cell.getStringCellValue() + "\t\t");
						break;

					default:
						System.out.println("DEFAULT " + cell.getAddress());
						//System.out.print("DEFAULT " + cell.getAddress() + " " + cell.getCellTypeEnum()
							//	+ "**CellDataformat** " + cell.getCellStyle().getDataFormatString() + ". Value="
								//+ cell.getRichStringCellValue() + "\t\t");

					}

				}

				// System.out.println("");
			}

			// System.out.println("Printing property names" + excelUpdates);
			Cell cell = null;
			// System.out.println("Printing property names"+excelUpdates);
			if (excelUpdates != null) {
				FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
				for (int i = 0; i < excelUpdates.length; i++) {
					if (excelUpdates[i] != null) {
						String prop = excelUpdates[i].getPropertyName();
						// System.out.println("Property Name:" + prop);
						if (prop.indexOf("R") > -1 && prop.indexOf("C") > -1) {
							int rowN = Integer.parseInt(prop.substring(1, prop.indexOf("C")));
							int colN = Integer.parseInt(prop.substring(prop.indexOf("C") + 1, prop.length()));
							// System.out.println(rowN + "=" + colN);
							cell = sheet.getRow(rowN).getCell(colN);
							String val = excelUpdates[i].getPropertyValue();
							if (val != null && cell != null && val != "") {
								// cell.
								// cell.setCellValue(val);
								// System.out.println("Style:"+cell.getCellStyle().);
								System.out.println(
										cell.getAddress()+", Cell TYPE==" + formulaEvaluator.evaluateInCell(cell).getCellTypeEnum());
								switch (formulaEvaluator.evaluateInCell(cell).getCellTypeEnum()) {
								case NUMERIC:
									if (val.indexOf("$") > -1) {
										val = val.replace("$", "");
										System.out.println("Number=" + val);
									}
									cell.setCellValue(Double.parseDouble(val));
									break;
								case BOOLEAN:
									cell.setCellValue(Boolean.parseBoolean(val));
									System.out.println("Boolean=" + val);
									break;
								case STRING:
									cell.setCellValue(val);
									System.out.println("String=" + val);
									break;
								default:
									if (DateUtil.isCellDateFormatted(cell)) {
										System.out
												.println("The cell contains a date value: " + cell.getDateCellValue());
									}
									if (val.indexOf("$") > -1) {
										val = val.replace("$", "");
										// cell.getC
										System.out.println("Double Number=" + val);
										cell.setCellValue(Double.parseDouble(val));
									} else {
										if (isNumeric(val)) {
											//cell.setCellValue(round(Double.parseDouble(val)));
											cell.setCellValue(Double.parseDouble(val));
										} else {
											cell.setCellValue(val);
										}
										// cell.set
										// cell.setCellStyle(style);
									}
									System.out.println("DeFAULT=" + val);
									// System.out.println(cell.get);
									//break;
								}

							}
						}
						// cell.setCellValue(excelUpdates[i].getPropertyValue());
						System.out.println(excelUpdates[i].getPropertyValue());
						// System.out.println("Property Name:"+prop);
						// System.out.println("Property
						// Value:"+excelUpdates.getPropertyValue(prop));

					}

				}

			}

			// sheet.getRow(0).get
			// Update the value of cell
			/*
			 * Cell cell = null; cell = sheet.getRow(0).getCell(4);
			 * cell.setCellValue("33333"); cell = sheet.getRow(4).getCell(1);
			 * //System.out.println(cell.get)); //cell.getCell
			 * cell.setCellValue(cell.getNumericCellValue() + 2); cell =
			 * sheet.getRow(5).getCell(1);
			 * cell.setCellValue(cell.getNumericCellValue() + 5);
			 */
			// byte[] fileContent = new byte[(int) file.];
			// FileInputStream inputStream = new FileInputStream(file);
			// read the contents of file into byte array
			// inputStream.read(fileContent);

			// FileOutputStream out = new FileOutputStream(new
			// File("C:\\temp\\actual_template3.xlsx"));
			// File file = new File(targetPath);
			// file.
			FileOutputStream out = new FileOutputStream(new File(targetPath));
			// out.
			// out.
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			// wb.
			wb.write(baos);
			fileContent = baos.toByteArray();
			wb.write(out);
			out.close();
			// File file = new File(targetPath);

			// wb.close();
			// wb.
			/*
			 * fileContent = new byte[(int) file.length()]; FileInputStream
			 * inputStream = null; try { // create an input stream pointing to
			 * the file inputStream = new FileInputStream(file); // read the
			 * contents of file into byte array //inputStream. //new
			 * InputStreamReader(inputStream, )), this.val$charLength);
			 * 
			 * inputStream.read(fileContent);
			 * 
			 * 
			 * } catch (IOException e) { throw new
			 * IOException("Unable to convert file to byte array. " +
			 * e.getMessage()); } finally { // close input stream if
			 * (inputStream != null) { inputStream.close(); } }
			 */
			wb.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			// close input stream
			if (fileIn != null) {
				fileIn.close();
			}
		}
		// Base64.getEncoder().
		String base64EncodedString = Base64.getEncoder().encodeToString(fileContent);
		return base64EncodedString;

	}

	public static boolean isNumeric(String str) {
		return str.matches("-?\\d+(\\.\\d+)?"); // match a number with optional
												// '-' and decimal.
	}

	public static double round21(double d) {
		BigDecimal bd = new BigDecimal(d);
		bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);
		return bd.doubleValue();

	}

}
