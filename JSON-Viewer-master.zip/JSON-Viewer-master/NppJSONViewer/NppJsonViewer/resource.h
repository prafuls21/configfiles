//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDD_TREEDLG                     101
#define IDD_SETTING                     102
#define IDD_ABOUTDLG                    103
#define IDR_TREEITEM_MENU               104
#define IDI_ICON_REFRESH                105
#define IDI_ICON_SEARCH                 106
#define IDI_ICON_FORMAT                 107
#define IDI_ICON_VALIDATE               108
#define IDI_ICON_TOOLBAR                109
#define IDC_TREE                        1001
#define IDC_WEB_SOURCE                  1002
#define IDC_WEB_ISSUE                   1003
#define IDC_GB_TITLE                    1004
#define IDC_SYSLINK_EMAIL               1006
#define IDC_BTN_REFRESH                 1007
#define IDC_BTN_FORMAT                  1008
#define IDC_EDT_NODEPATH                1009
#define IDC_EDT_SEARCH                  1010
#define IDC_BTN_SEARCH                  1011
#define IDC_DIVIDER                     1012
#define IDC_BTN_VALIDATE                1013
#define IDC_HOR_BAR_TOP                 1014
#define IDC_HOR_BAR_BOTTOM              1015
#define IDC_RADIO_LINE_AUTO             1016
#define IDC_RADIO_LINE_WINDOW           1017
#define IDC_RADIO_LINE_UNIX             1018
#define IDC_RADIO_LINE_MAC              1019
#define IDC_RADIO_INDENT_AUTO           1020
#define IDC_RADIO_INDENT_TAB            1021
#define IDC_RADIO_INDENT_SPACE          1022
#define IDC_EDT_INDENT_SPACECOUNT       1023
#define IDC_STATIC_SPACECOUNT           1024
#define IDC_RADIO_LINEFORMAT_DEFAULT    1025
#define IDC_RADIO_LINEFORMAT_SINGLE     1026
#define IDC_CHK_FOLLOW_CURRENT_DOC      1028
#define IDC_CHK_FORMAT_ON_OPEN          1029
#define IDC_CHK_IGNORE_COMMA            1030
#define IDC_CHK_IGNORE_COMMENT          1031
#define IDC_CHK_JSON_HIGHLIGHT          1032
#define IDC_CHK_REPLACE_UNDEFINED       1033
#define IDM_COPY_TREEITEM               40001
#define IDM_COPY_NODENAME               40002
#define IDM_COPY_NODEVALUE              40003
#define IDM_COPY_NODEPATH               40004
#define IDM_EXPANDALL                   40005
#define IDM_COLLAPSEALL                 40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
