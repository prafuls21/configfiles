package application.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.kie.api.runtime.KieSession;

import org.kie.api.task.TaskService;
import org.kie.api.task.model.TaskSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import application.entity.User;
import application.repository.UserRepository;


@EnableSwagger2
@RestController
@RequestMapping(value = "/api")
public class ProcessController {

    @Autowired
    private KieSession kieSession;
    @Autowired
    private TaskService taskService;
    @Autowired
    private UserRepository userRepository;

    @RequestMapping(value="index")
    public String Index() {
        return "<h1 style='color:red'>Welcome, Please Login!</h1>";
    }
    @RequestMapping(value="error")
    public String error() {
        return "<h1 style='color:red'>User have no right to access!</h1>";
    }

    @PostMapping(value = "startProcess")
    public Long startProcess(String userId) {
        Map<String, Object> data = new HashMap<String, Object>(16);
        data.put("Manager", userId);
        return kieSession.startProcess("TestProjectCh.Test", data).getId();
    }
    @GetMapping(value="getTasks")
    public List<TaskSummary> getTask() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        return taskService.getTasksAssignedAsPotentialOwner(auth.getName(), "en_US");
    }
    @PostMapping("startTask")
    public void startTask(String userId,Long taskId) {
        taskService.start(taskId, userId);
    }
    @PostMapping("completeTask")
    public void completeTask(String userId,Long taskId) {
        taskService.complete(taskId, userId, null);
    }

    @PostMapping("claim")
    public void calim(String userId,Long taskId) {
        taskService.claim(taskId, userId);
    }


    @GetMapping("getUserByUsername/{username}")
    public User getUserName(@PathVariable("username") String username) {

        User user=userRepository.findUserByName(username);
        System.out.println(userRepository.getClass());
        return user;
    }

}
