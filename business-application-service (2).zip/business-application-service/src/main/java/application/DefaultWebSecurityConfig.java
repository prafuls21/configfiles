
package application;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import application.service.UserService;

@Configuration("kieServerSecurity")
@EnableWebSecurity
public class DefaultWebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private UserService userService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        //BCryptPasswordEncoder 123456
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        System.out.println("123456 "+passwordEncoder.encode("123456"));
        return passwordEncoder;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // TODO Auto-generated method stub
        http.cors().and().csrf().disable().authorizeRequests().antMatchers("/api/index","/api/error","/rest/**").permitAll().antMatchers("/api/**","/swagger*/**","/webjars/**")
                //.hasRole("Administrators")
                .authenticated()
                .and().exceptionHandling().accessDeniedHandler(new AccessDeniedHandler() {

                    @Override
                    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException arg2)
                            throws IOException, ServletException {
                        response.sendRedirect("/bpm/api/error");
                    }
                }).and().httpBasic()
                .and().headers().frameOptions().disable().and().formLogin().usernameParameter("username").passwordParameter("password").loginProcessingUrl("/login").and()
                .logout().logoutUrl("/logout").logoutSuccessHandler(new LogoutSuccessHandler() {

                    @Override
                    public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication arg2)
                            throws IOException, ServletException {
                        response.sendRedirect("/bpm/api/index");

                    }
                });
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userService).passwordEncoder(passwordEncoder());
    }
}
