package application.config;

import javax.persistence.EntityManagerFactory;
import org.jbpm.runtime.manager.impl.RuntimeEnvironmentBuilder;
import org.jbpm.services.task.identity.DBUserGroupCallbackImpl;
import org.kie.api.io.ResourceType;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.RuntimeEngine;
import org.kie.api.runtime.manager.RuntimeEnvironment;
import org.kie.api.runtime.manager.RuntimeManager;
import org.kie.api.runtime.manager.RuntimeManagerFactory;
import org.kie.api.task.TaskService;
import org.kie.internal.io.ResourceFactory;
import org.kie.internal.runtime.manager.context.EmptyContext;
import org.kie.internal.task.api.UserGroupCallback;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

@Configuration
public class JbpmConfig {

    @Bean
    RuntimeEnvironment runtimeEnvironment(EntityManagerFactory entityManagerFactory) {
        RuntimeEnvironment runtimeEnvironment = RuntimeEnvironmentBuilder.Factory.get()
                .newDefaultBuilder().entityManagerFactory(entityManagerFactory)

                .addAsset(ResourceFactory.newClassPathResource("Test.bpmn"), ResourceType.BPMN2)
                .get();
        return runtimeEnvironment;
    }

    @Bean
    RuntimeManager runtimeManager(RuntimeManagerFactory runtimeManagerFactory,RuntimeEnvironment runtimeEnvironment) {
        RuntimeManager runtimeManager = runtimeManagerFactory.newSingletonRuntimeManager(runtimeEnvironment);
        return runtimeManager;
    }
    @Bean
    RuntimeEngine runtimeEngine(RuntimeManager runtimeManager) {
        RuntimeEngine runtimeEngine = runtimeManager.getRuntimeEngine(EmptyContext.get());
        return runtimeEngine;
    }
    @Bean
    KieSession kieSession(RuntimeEngine runtimeEngine) {
        KieSession kieSession = runtimeEngine.getKieSession();
        return kieSession;
    }
    @Bean
    TaskService taskService(RuntimeEngine runtimeEngine) {
        TaskService taskService = runtimeEngine.getTaskService();
        return taskService;
    }
    //userGroupCallback SpringSecurityUserGroupCallback userGroupCallback bean，
    // DBUserGroupCallbackImpl userGroupCallback的bean，
    // jbpm.usergroup.callback.properties
    @Bean
    @DependsOn("jndiDataSource")
    UserGroupCallback userGroupCallback() {
        return new DBUserGroupCallbackImpl(true);
    }


}